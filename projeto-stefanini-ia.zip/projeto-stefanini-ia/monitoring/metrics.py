"""
Coleta de métricas em formato JSON Lines.
Compatível com pipelines do Elastic/Kibana e com Grafana (via Loki/Promtail).
"""
import json
import os
from datetime import datetime
from typing import Dict

METRICS_DIR = "logs"
METRICS_FILE = os.path.join(METRICS_DIR, "metrics.jsonl")


def emit(metric_name: str, value: float, labels: Dict[str, str] | None = None) -> None:
    os.makedirs(METRICS_DIR, exist_ok=True)
    record = {
        "timestamp": datetime.utcnow().isoformat() + "Z",
        "metric": metric_name,
        "value": value,
        "labels": labels or {},
    }
    with open(METRICS_FILE, "a", encoding="utf-8") as f:
        f.write(json.dumps(record) + "\n")


def summarize() -> Dict:
    """Resumo rápido das métricas registradas (útil para dashboard)."""
    if not os.path.exists(METRICS_FILE):
        return {"count": 0}

    by_metric: Dict[str, list] = {}
    with open(METRICS_FILE, encoding="utf-8") as f:
        for line in f:
            rec = json.loads(line)
            by_metric.setdefault(rec["metric"], []).append(rec["value"])

    summary = {"count": sum(len(v) for v in by_metric.values())}
    for name, values in by_metric.items():
        summary[name] = {
            "count": len(values),
            "avg": round(sum(values) / len(values), 3),
            "max": round(max(values), 3),
            "min": round(min(values), 3),
        }
    return summary