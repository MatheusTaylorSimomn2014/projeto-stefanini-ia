"""
Wrapper para Elasticsearch com modo MOCK.
Em produção, basta preencher ELÁSTIC_* no .env que ele conecta de verdade.
"""
import os
from datetime import datetime
from typing import Dict, List

try:
    from elasticsearch import Elasticsearch
except ImportError:
    Elasticsearch = None


class ElasticClient:
    def __init__(self) -> None:
        self.index = os.getenv("ELASTIC_INDEX", "stefanini-logs")
        self._client = None
        self._mock_store: List[Dict] = []
        self._connect()

    def _connect(self) -> None:
        url = os.getenv("ELASTIC_URL")
        if url and Elasticsearch:
            self._client = Elasticsearch(
                [url],
                basic_auth=(
                    os.getenv("ELASTIC_USER", ""),
                    os.getenv("ELASTIC_PASSWORD", ""),
                ),
            )

    @property
    def mode(self) -> str:
        return "real" if self._client else "mock"

    def index_document(self, doc: Dict) -> Dict:
        """Indexa um documento (log, interação do chatbot etc)."""
        doc = {**doc, "indexed_at": datetime.utcnow().isoformat() + "Z"}
        if self._client:
            return self._client.index(index=self.index, document=doc)
        self._mock_store.append(doc)
        return {"result": "created (mock)", "doc": doc}

    def search(self, query_text: str, size: int = 10) -> List[Dict]:
        """Busca full-text (mock retorna filtragem simples)."""
        if self._client:
            resp = self._client.search(
                index=self.index,
                query={"match": {"user_message": query_text}},
                size=size,
            )
            return [hit["_source"] for hit in resp["hits"]["hits"]]
        return [d for d in self._mock_store if query_text.lower() in str(d).lower()][:size]